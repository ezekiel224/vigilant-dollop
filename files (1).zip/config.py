"""
music-autodl — configuration
All settings are read from a .env file (auto-detected) or environment variables.

.env is loaded HERE, at the top of this module, before any os.getenv() call.
This avoids the classic Python gotcha where dataclass field defaults are
evaluated at import time — before main.py has a chance to call load_dotenv().
"""
import os
from pathlib import Path
from dataclasses import dataclass, field

# ── Load .env immediately ────────────────────────────────────────────────────
# Search for .env in the script's directory AND the current working directory.
def _load_env():
    try:
        from dotenv import load_dotenv
    except ImportError:
        return  # python-dotenv not installed; rely on real env vars

    # Prefer .env next to this file (works regardless of where you run from)
    candidates = [
        Path(__file__).parent / ".env",
        Path.cwd() / ".env",
    ]
    for path in candidates:
        if path.exists():
            load_dotenv(dotenv_path=path, override=False)
            return
    # If neither exists, load_dotenv() will still pick up any real env vars
    load_dotenv(override=False)

_load_env()

# ── Now safe to call os.getenv() ─────────────────────────────────────────────

@dataclass
class PlexConfig:
    url:          str  = field(default_factory=lambda: os.getenv("PLEX_URL",           "http://localhost:32400"))
    token:        str  = field(default_factory=lambda: os.getenv("PLEX_TOKEN",         ""))
    library_name: str  = field(default_factory=lambda: os.getenv("PLEX_MUSIC_LIBRARY", "Music"))
    enabled:      bool = field(default_factory=lambda: bool(os.getenv("PLEX_TOKEN",    "")))


@dataclass
class LastFmConfig:
    api_key:   str   = field(default_factory=lambda: os.getenv("LASTFM_API_KEY",   ""))
    username:  str   = field(default_factory=lambda: os.getenv("LASTFM_USERNAME",  ""))
    period:    str   = field(default_factory=lambda: os.getenv("LASTFM_PERIOD",    "1month"))
    top_limit: int   = field(default_factory=lambda: int(os.getenv("LASTFM_TOP_LIMIT", "50")))
    enabled:   bool  = field(default_factory=lambda: bool(
        os.getenv("LASTFM_API_KEY", "") and os.getenv("LASTFM_USERNAME", "")
    ))


@dataclass
class SpotifyConfig:
    client_id:     str  = field(default_factory=lambda: os.getenv("SPOTIFY_CLIENT_ID",     ""))
    client_secret: str  = field(default_factory=lambda: os.getenv("SPOTIFY_CLIENT_SECRET", ""))
    redirect_uri:  str  = field(default_factory=lambda: os.getenv("SPOTIFY_REDIRECT_URI",  "http://localhost:9090"))
    scope:         str  = "user-top-read user-read-recently-played user-follow-read"
    time_range:    str  = field(default_factory=lambda: os.getenv("SPOTIFY_TIME_RANGE", "medium_term"))
    top_limit:     int  = field(default_factory=lambda: int(os.getenv("SPOTIFY_TOP_LIMIT", "50")))
    enabled:       bool = field(default_factory=lambda: bool(
        os.getenv("SPOTIFY_CLIENT_ID", "") and os.getenv("SPOTIFY_CLIENT_SECRET", "")
    ))


@dataclass
class TidalConfig:
    session_file: str  = field(default_factory=lambda: os.getenv("TIDAL_SESSION_FILE", "./tidal_session.json"))
    enabled:      bool = field(default_factory=lambda: (
        os.getenv("TIDAL_ENABLED", "true").lower() in ("1", "true", "yes")
    ))


@dataclass
class TidarrConfig:
    url:     str  = field(default_factory=lambda: os.getenv("TIDARR_URL", "http://tidarr:8484"))
    api_key: str  = field(default_factory=lambda: os.getenv("TIDARR_KEY", ""))
    enabled: bool = True


@dataclass
class RecommendationConfig:
    similar_per_artist: int   = field(default_factory=lambda: int(os.getenv("SIMILAR_PER_ARTIST", "10")))
    min_similarity:     float = field(default_factory=lambda: float(os.getenv("MIN_SIMILARITY",   "0.3")))
    skip_existing:      bool  = field(default_factory=lambda: (
        os.getenv("SKIP_EXISTING", "true").lower() in ("1", "true", "yes")
    ))
    max_new_per_run:    int   = field(default_factory=lambda: int(os.getenv("MAX_NEW_PER_RUN", "0")))
    schedule:           str   = field(default_factory=lambda: os.getenv("SCHEDULE", "0 3 * * *"))
    seen_db:            str   = field(default_factory=lambda: os.getenv("SEEN_DB", "./seen_artists.json"))


@dataclass
class AppConfig:
    plex:      PlexConfig           = field(default_factory=PlexConfig)
    lastfm:    LastFmConfig         = field(default_factory=LastFmConfig)
    spotify:   SpotifyConfig        = field(default_factory=SpotifyConfig)
    tidal:     TidalConfig          = field(default_factory=TidalConfig)
    tidarr:    TidarrConfig         = field(default_factory=TidarrConfig)
    rec:       RecommendationConfig = field(default_factory=RecommendationConfig)
    log_level: str                  = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))


# Singleton — all consumers import this
cfg = AppConfig()
