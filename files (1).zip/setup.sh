#!/usr/bin/env bash
# setup.sh — install all dependencies for music-autodl
# Run once: bash setup.sh
set -e

echo "Installing music-autodl dependencies..."

pip3 install --user \
    python-dotenv \
    requests \
    apscheduler \
    plexapi \
    spotipy \
    tidalapi

echo ""
echo "✓ All dependencies installed."
echo ""
echo "Next steps:"
echo "  1. Make sure your .env file is in this directory"
echo "  2. python3 main.py --dry-run   (preview candidates)"
echo "  3. python3 main.py             (run for real)"
