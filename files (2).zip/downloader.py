"""
core/downloader.py — queue artists in Tidarr via its SABnzbd-compatible API.

Tidarr's correct download endpoint is:
  GET /api/sabnzbd/api?mode=addurl&name={tidal_url}&apikey={key}

By default Tidarr already expands an artist URL into one queue item per album,
so we just send the artist URL and let Tidarr handle the rest. This is simpler,
more reliable, and matches how Tidarr is designed to be used.
"""
import logging
import requests

log = logging.getLogger(__name__)


class TidarrDownloader:

    def __init__(self, cfg):
        self.base = cfg.tidarr.url.rstrip("/")
        self.key  = cfg.tidarr.api_key

    def _params(self, extra: dict = None) -> dict:
        p = {}
        if self.key:
            p["apikey"] = self.key
        if extra:
            p.update(extra)
        return p

    def queue_artist(self, artist_name: str, tidal_artist_id: int) -> bool:
        """
        Send the Tidal artist URL to Tidarr. Tidarr will expand it into one
        queue item per album automatically (unless ARTIST_SINGLE_DOWNLOAD=true).
        Returns True if Tidarr accepted the request.
        """
        tidal_url = f"https://listen.tidal.com/artist/{tidal_artist_id}"
        log.info("⬇  Queuing artist: %s  →  %s", artist_name, tidal_url)

        try:
            r = requests.get(
                f"{self.base}/api/sabnzbd/api",
                params=self._params({"mode": "addurl", "name": tidal_url}),
                timeout=15,
            )
            r.raise_for_status()
            log.info("  ✓ Tidarr accepted: %s", artist_name)
            return True
        except Exception as exc:
            log.error("  ✗ Tidarr rejected %s: %s", artist_name, exc)
            return False

    def health_check(self) -> bool:
        try:
            r = requests.get(
                f"{self.base}/api/sabnzbd/api",
                params=self._params({"mode": "queue"}),
                timeout=5,
            )
            return r.ok
        except Exception:
            return False
