#!/usr/bin/env python3
"""
music-autodl — main runner
"""

import argparse
import logging
import sys
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("autodl")

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from config import cfg
from core.seen_db     import SeenDB
from core.recommender import build_recommendations, load_blocklist
from core.downloader  import TidarrDownloader


def run_once(dry_run: bool = False):
    log.info("━" * 60)
    log.info("  music-autodl  %s  %s",
             "DRY RUN" if dry_run else "starting run",
             datetime.now().strftime("%Y-%m-%d %H:%M"))
    log.info("━" * 60)

    dl   = TidarrDownloader(cfg)
    seen = SeenDB(cfg.rec.seen_db)

    # Pre-populate existing set from seen DB
    existing_artists: set[str] = set(seen._data)

    # Build ranked candidate list
    candidates = build_recommendations(cfg, existing_artists)

    if not candidates:
        log.info("No new candidates — nothing to do.")
        return

    log.info("Top candidates:")
    for i, c in enumerate(candidates[:15], 1):
        id_str = f"tidal:{c.tidal_id}" if c.tidal_id else "id:?"
        log.info("  %2d. %-35s  score=%.2f  %-12s  sources=%d",
                 i, c.name, c.score, id_str, len(c.sources))

    if dry_run:
        print(f"\n{'#':>3}  {'Artist':<38}  {'Score':>6}  {'Tidal ID':>10}  Sources")
        print("─" * 75)
        for i, c in enumerate(candidates, 1):
            print(f"{i:>3}. {c.name:<38}  {c.score:>6.2f}  "
                  f"{str(c.tidal_id) if c.tidal_id else '?':>10}  {len(c.sources)}")
        return

    # ── Download ────────────────────────────────────────────────────────────
    if not dl.health_check():
        log.error("Tidarr is unreachable at %s — aborting", cfg.tidarr.url)
        return

    total = 0
    for candidate in candidates:
        if seen.seen(candidate.name):
            log.debug("Already queued: %s", candidate.name)
            continue

        # Resolve Tidal ID if we don't have it yet (came from Last.fm / Spotify / Plex)
        tidal_id = candidate.tidal_id
        if tidal_id is None:
            from sources.tidal import search_artist_id
            tidal_id = search_artist_id(candidate.name, cfg)

        if tidal_id is None:
            log.warning("✗ No Tidal match found for: %s — skipping", candidate.name)
            seen.mark(candidate.name)   # mark so we don't retry every run
            continue

        ok = dl.queue_artist(candidate.name, tidal_id)
        seen.mark(candidate.name)       # mark regardless so we don't spam Tidarr
        if ok:
            total += 1

    log.info("━" * 60)
    log.info("  Run complete — %d artist(s) queued in Tidarr", total)
    log.info("━" * 60)


def run_daemon():
    try:
        from apscheduler.schedulers.blocking import BlockingScheduler
        from apscheduler.triggers.cron import CronTrigger
    except ImportError:
        log.error("APScheduler not installed — run: bash setup.sh")
        sys.exit(1)

    scheduler = BlockingScheduler(timezone="UTC")
    trigger   = CronTrigger.from_crontab(cfg.rec.schedule)
    scheduler.add_job(run_once, trigger, id="autodl", max_instances=1)
    log.info("Daemon mode: schedule='%s' UTC. Running first cycle now…", cfg.rec.schedule)
    run_once()
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        log.info("Daemon stopped.")


def main():
    logging.getLogger().setLevel(getattr(logging, cfg.log_level.upper(), logging.INFO))

    parser = argparse.ArgumentParser(description="music-autodl")
    parser.add_argument("--daemon",  action="store_true", help="Run on SCHEDULE forever")
    parser.add_argument("--dry-run", action="store_true", help="Show candidates, no downloads")
    args = parser.parse_args()

    if args.daemon:
        run_daemon()
    else:
        run_once(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
