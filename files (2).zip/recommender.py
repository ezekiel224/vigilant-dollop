"""
core/recommender.py — aggregate seeds, expand via similarity, filter, score, rank.
"""
import logging
from collections import defaultdict
from pathlib import Path
from typing import NamedTuple

log = logging.getLogger(__name__)


class Candidate(NamedTuple):
    name:       str
    tidal_id:   int | None   # None until resolved; downloader will search if needed
    score:      float
    sources:    list[str]


def load_blocklist(path: str) -> set[str]:
    """
    Read blocklist.txt — one artist name per line, # = comment.
    Returns a set of lowercased names.
    """
    p = Path(path)
    if not p.exists():
        return set()

    blocked = set()
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        blocked.add(line.lower())

    if blocked:
        log.info("Blocklist: loaded %d blocked artists from %s", len(blocked), p)
    return blocked


def build_recommendations(cfg, existing_artists: set[str]) -> list[Candidate]:
    """
    Full pipeline:
      1. Collect seed artists from all enabled sources
      2. Expand via Last.fm + Tidal similar-artist APIs
      3. Filter: not in library, not in seen DB, not in blocklist
      4. Score by multi-source consensus
      5. Return ranked Candidate list
    """
    from sources.plex    import get_library_artists
    from sources.lastfm  import get_top_artists as lfm_top, get_similar_artists as lfm_similar
    from sources.spotify import get_top_artists as sp_top
    from sources.tidal   import get_favorite_artists as tidal_favs, get_similar_artists as tidal_similar

    blocklist = load_blocklist(cfg.rec.blocklist)

    # ── Step 1: Gather seed artists ─────────────────────────────────────────
    # seeds maps lowercase name → tidal_id (or None if unknown)
    seeds: dict[str, int | None] = {}

    # Plex — names only
    for name in get_library_artists(cfg):
        seeds[name.lower()] = None
        existing_artists.add(name.lower())

    # Last.fm — names only
    for name in lfm_top(cfg):
        seeds.setdefault(name.lower(), None)

    # Spotify — names only
    for name in sp_top(cfg):
        seeds.setdefault(name.lower(), None)

    # Tidal — names + IDs
    for entry in tidal_favs(cfg):
        key = entry["name"].lower()
        seeds[key] = entry.get("tidal_id")
        # Tidal favourites are also seeds for expansion,
        # but NOT automatically added to existing (user may not have downloaded them yet)

    log.info("Recommender: %d unique seed artists collected", len(seeds))

    # ── Step 2: Expand via similarity ────────────────────────────────────────
    # votes[name_lower] = list of (score, source_label, tidal_id_or_None)
    votes: dict[str, list[tuple[float, str, int | None]]] = defaultdict(list)

    # cache original casing per lowercase key
    casing: dict[str, str] = {k: k for k in seeds}

    seeds_list = list(seeds.items())
    for i, (seed_lower, seed_tidal_id) in enumerate(seeds_list, 1):
        seed_display = casing.get(seed_lower, seed_lower)
        log.debug("Expanding %d/%d: %s", i, len(seeds_list), seed_display)

        if cfg.lastfm.enabled:
            for rec in lfm_similar(
                seed_display,
                cfg.lastfm.api_key,
                limit=cfg.rec.similar_per_artist,
                min_match=cfg.rec.min_similarity,
            ):
                rname = rec["name"]
                rkey  = rname.lower()
                casing.setdefault(rkey, rname)
                votes[rkey].append((rec["match"], f"lastfm~{seed_display}", None))

        if cfg.tidal.enabled:
            for rec in tidal_similar(seed_display, cfg, limit=cfg.rec.similar_per_artist):
                rname = rec["name"]
                rkey  = rname.lower()
                casing.setdefault(rkey, rname)
                votes[rkey].append((rec["match"], f"tidal~{seed_display}", rec.get("tidal_id")))

    log.info("Recommender: %d raw candidates from expansion", len(votes))

    # ── Step 3: Filter ───────────────────────────────────────────────────────
    filtered = {}
    for name_lower, vote_list in votes.items():
        if name_lower in existing_artists:
            continue
        if name_lower in blocklist:
            log.debug("Blocklist: skipping %s", name_lower)
            continue
        filtered[name_lower] = vote_list

    log.info("Recommender: %d candidates after filtering", len(filtered))

    # ── Step 4: Score and build candidates ───────────────────────────────────
    candidates = []
    for name_lower, vote_list in filtered.items():
        unique_sources = list({v[1] for v in vote_list})
        avg_match      = sum(v[0] for v in vote_list) / len(vote_list)
        score          = len(unique_sources) * avg_match

        # Grab the best tidal_id we have from votes (may be None)
        tidal_id = next((v[2] for v in vote_list if v[2] is not None), None)

        candidates.append(Candidate(
            name     = casing.get(name_lower, name_lower.title()),
            tidal_id = tidal_id,
            score    = score,
            sources  = unique_sources,
        ))

    candidates.sort(key=lambda c: c.score, reverse=True)

    if cfg.rec.max_new_per_run > 0:
        candidates = candidates[:cfg.rec.max_new_per_run]

    log.info("Recommender: returning %d ranked candidates", len(candidates))
    return candidates
