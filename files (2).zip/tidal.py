"""
sources/tidal.py — pull favourite artists from TIDAL and expand via similar artists.

Session is a module-level singleton so auth happens once per process.
"""
import logging
from pathlib import Path

log = logging.getLogger(__name__)

_session = None


def _get_session(cfg):
    global _session
    if _session is not None and _session.check_login():
        return _session

    if not cfg.tidal.enabled:
        return None

    try:
        import tidalapi
    except ImportError:
        log.error("tidalapi not installed — run: bash setup.sh")
        return None

    session_path = Path(cfg.tidal.session_file)
    session_path.parent.mkdir(parents=True, exist_ok=True)

    session = tidalapi.Session()
    try:
        ok = session.login_session_file(session_path, do_pkce=True)
    except Exception as exc:
        log.error("Tidal: login failed — %s", exc)
        return None

    if not ok:
        log.error("Tidal: login_session_file returned False")
        return None

    log.info("Tidal: logged in (session saved to %s)", session_path)
    _session = session
    return _session


def get_favorite_artists(cfg) -> list[dict]:
    """
    Return list of dicts: {"name": str, "tidal_id": int}
    for all TIDAL-favourited artists.
    """
    if not cfg.tidal.enabled:
        log.info("Tidal: disabled")
        return []

    session = _get_session(cfg)
    if not session:
        return []

    try:
        artists = session.user.favorites.artists()
        result = [{"name": a.name, "tidal_id": a.id} for a in artists if a.name]
        log.info("Tidal: fetched %d favourite artists", len(result))
        return result
    except Exception as exc:
        log.error("Tidal: could not fetch favourites — %s", exc)
        return []


def get_similar_artists(artist_name: str, cfg, limit: int = 10) -> list[dict]:
    """
    Returns list of dicts: {"name": str, "tidal_id": int, "match": float, "source": "tidal"}
    """
    session = _get_session(cfg)
    if not session:
        return []

    try:
        import tidalapi as _tidalapi
        results = session.search(artist_name, models=[_tidalapi.Artist])
        artist_list = results.get("artists") or []
        if not artist_list:
            return []

        tidal_artist = artist_list[0]
        try:
            similar = tidal_artist.get_similar() or []
            return [
                {"name": a.name, "tidal_id": a.id, "match": 0.5, "source": "tidal"}
                for a in similar if a.name
            ][:limit]
        except Exception:
            return []

    except Exception as exc:
        log.debug("Tidal: similar lookup failed for %r — %s", artist_name, exc)
        return []


def search_artist_id(artist_name: str, cfg) -> int | None:
    """
    Look up a Tidal artist ID by name. Used by the downloader when we only
    have a name (e.g. from Last.fm / Spotify / Plex sources).
    Returns the Tidal artist ID or None if not found.
    """
    session = _get_session(cfg)
    if not session:
        return None

    try:
        import tidalapi as _tidalapi
        results = session.search(artist_name, models=[_tidalapi.Artist])
        artists = results.get("artists") or []
        if artists:
            return artists[0].id
        return None
    except Exception as exc:
        log.debug("Tidal: search failed for %r — %s", artist_name, exc)
        return None
